document.addEventListener("DOMContentLoaded", () => {

    const $ = id => document.getElementById(id);

    /* =======================
       LED GLOW
    ======================= */
    function updateLedGlow(val) {
        document.querySelectorAll(".cmd-btn").forEach(btn => {
            const bit = parseInt(btn.dataset.cmd, 10);
            btn.classList.toggle("glow", (val & bit) !== 0);
        });
    }

    async function pollLed() {
        try {
            const r = await fetch("?action=led");
            const j = await r.json();
            updateLedGlow(j.led);
        } catch { }
    }

    /* =======================
       STATUS
    ======================= */
    async function fetchStatus() {
        const r = await fetch("?action=read");
        const d = await r.json();

        $("current").textContent =
            Number(d.temperature).toFixed(1) + " °F";

        $("last-updated").textContent =
            "Last update: " + new Date().toLocaleTimeString();

        updateLedGlow(d.led);
        loadHistory();
    }

    /* =======================
       HISTORY + TOOLTIP
    ======================= */
    async function loadHistory() {
        const chart = $("chart");
        const tooltip = $("tooltip");
        chart.querySelectorAll(".bar").forEach(b => b.remove());

        const r = await fetch("?action=history");
        const data = await r.json();

        data.forEach(d => {
            const temp = Number(d.temperature);
            const bar = document.createElement("div");
            bar.className = "bar";
            bar.style.height = Math.min(200, temp * 2) + "px";

            bar.addEventListener("mouseenter", e => {
                tooltip.textContent =
                    `${temp.toFixed(1)} °F @ ${d.timestamp}`;
                tooltip.style.left = e.target.offsetLeft + "px";
                tooltip.style.bottom = bar.style.height;
                tooltip.style.opacity = 1;
            });

            bar.addEventListener("mouseleave", () => {
                tooltip.style.opacity = 0;
            });

            chart.appendChild(bar);
        });
    }

    /* =======================
       COMMAND SEND
    ======================= */
    document.querySelectorAll(".cmd-btn").forEach(btn => {
        btn.addEventListener("click", async () => {
            const cmd = btn.dataset.cmd;
            await fetch("?action=send", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "cmd=" + encodeURIComponent(cmd)
            });
        });
    });

    /* =======================
       TIMERS
    ======================= */
    fetchStatus();
    setInterval(fetchStatus, 300000);
    setInterval(pollLed, 500);

});
