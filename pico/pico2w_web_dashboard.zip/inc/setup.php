<?php
/* =======================
   CONFIG / SETUP
======================= */
$PICO_URL = "http://192.168.1.x"; // Use your PICO 2W's I.P. address!
$DB_HOST  = "192.168.1.x"; // Your MrSQL/MariaDB host.
$DB_USER  = "pico"; // DB username.
$DB_PASS  = "pico"; // DB Password.
$DB_NAME  = "pico"; // Name of the DB you're using.

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    exit("Database connection failed");
}

?>