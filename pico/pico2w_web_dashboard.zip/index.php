<?php require_once("inc/setup.php"); ?>
<?php require_once("inc/ajax.php"); ?>
<?php require_once("inc/index.html"); ?>
